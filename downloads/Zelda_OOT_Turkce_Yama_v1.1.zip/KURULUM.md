# The Legend of Zelda: Ocarina of Time Türkçe Yama

**Çevirmen: HarunSins**

Oyun sürümü **2.0.0** · Oyun kimliği **`0400486024DEC000`** · Oyun dili **American English**

## Kurulum

1. Oyunu kapat ve ZIP’i çıkar.
2. Emülatörde oyuna sağ tıklayıp mod klasörünü aç. Önceki `TurkceYama` klasörünü yedeklemek için mod dizininin dışına taşı.
3. Paketteki `TurkceYama` klasörünü bütünüyle mod dizinine kopyala. Dizin yapısı `0400486024DEC000/TurkceYama/romfs` olmalı.
4. Oyunun dilini **American English / Amerikan İngilizcesi** olarak ayarla, `TurkceYama` modunu etkinleştir ve oyunu aç.

Bağımsız hayran çevirisi.

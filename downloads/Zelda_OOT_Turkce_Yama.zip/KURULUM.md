# The Legend of Zelda: Ocarina of Time Türkçe Yama v0.4.3

**Çeviri: HarunSins**

Oyun sürümü **2.0.0** · Oyun kimliği **`0400486024DEC000`** · Oyun dili **American English**

## Kurulum

1. ZIP’i çıkar. Emülatörde oyuna sağ tıkla ve oyunun mod klasörünü aç.
2. Oyun kapalıyken varsa eski Türkçe yama klasörünü mod dizininin dışına taşı.
3. ZIP’teki `TurkceYama` klasörünü oyunun mod klasörüne kopyala. Klasör dizilimi `0400486024DEC000/TurkceYama/romfs` olmalı.
4. Oyun ayarlarında **American English / Amerikan İngilizcesi** dilini seç ve `TurkceYama` modunu etkinleştir.

Yamayı kaldırmak için oyun kapalıyken `TurkceYama` klasörünü mod dizininden çıkar.

- Ara sahnelerde ve bölge başlıklarında kullanılan süslemeli yazı tiplerine Türkçe harf desteği eklendi.
- Oyun sonu jeneriğinin başına çeviri kredisi eklendi.

Bu bağımsız bir hayran çevirisidir. Paket, mod dosyalarını ve bu kurulum belgesini içerir.
